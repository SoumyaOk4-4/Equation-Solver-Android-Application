package kotlintry.soumya.crammersrulekotlin.equationsolver10

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlintry.soumya.crammersrulekotlin.equationsolver10.R.id.processor

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // This is to hide the title bar
        supportActionBar?.hide()

        setContentView(R.layout.activity_main)
    }
    fun equ(v: View){
        // This is for declaring the variables and call those ids
        val processor = findViewById<Button>(processor)

        val x1Coefficient = findViewById<EditText>(R.id.x1Coefficient)
        val y1Coefficient = findViewById<EditText>(R.id.y1Coefficient)
        val num1 = findViewById<EditText>(R.id.num1)

        val x2Coefficient = findViewById<EditText>(R.id.x2Coefficient)
        val y2Coefficient = findViewById<EditText>(R.id.y2Coefficient)
        val num2 = findViewById<EditText>(R.id.num2)

        val answer_x = findViewById<TextView>(R.id.answer_x)
        val answer_y = findViewById<TextView>(R.id.answer_y)

        val x1: Float
        val y1: Float
        val n1: Float

        val x2: Float
        val y2: Float
        val n2: Float

            /* This variables are for calculation */
        val D: Float
        val D1: Float
        val D2: Float
        val x: Float
        val y: Float

        val x_ans: String
        val y_ans: String

            /* Equation 1 */
        if (TextUtils.isEmpty(x1Coefficient.text.toString())) {
            x1Coefficient.error = "Enter any number..."
            return
        }else {
            x1 = x1Coefficient.text.toString().toFloat()
        }
        if (TextUtils.isEmpty(y1Coefficient.text.toString())){
            y1Coefficient.error = "Enter any number..."
            return
        }else {
            y1 = y1Coefficient.text.toString().toFloat()
        }
        if (TextUtils.isEmpty(num1.text.toString())){
            num1.error = "Enter any number..."
            return
        }else{
            n1 = num1.text.toString().toFloat()
        }
            /* Equation 2 */
        if (TextUtils.isEmpty(x2Coefficient.text.toString())) {
            x2Coefficient.error = "Enter any number..."
            return
        }else {
            x2 = x2Coefficient.text.toString().toFloat()
        }
        if (TextUtils.isEmpty(y2Coefficient.text.toString())){
            y2Coefficient.error = "Enter any number..."
            return
        }else {
            y2 = y2Coefficient.text.toString().toFloat()
        }
        if (TextUtils.isEmpty(num2.text.toString())){
            num2.error = "Enter any number..."
            return
        }else{
            n2 = num2.text.toString().toFloat()
        }

            /* Logic / Crammer's Rule */
        when(v.id){
            R.id.processor -> {
                D = (x1 * y2) - (x2 * y1)
                D1 = (n1 * y2) - (n2 * y1)
                D2 = (x1 * n2) - (x2 * n1)

                x = D1 / D
                y = D2 / D

                x_ans = "X = $x"
                y_ans = "Y = $y"

                answer_x.text = x_ans.toString()
                answer_y.text = y_ans.toString()
            }
        }
    }
}